-- creazione database
create database if not exists ToysGroup;
use ToysGroup;
-- creazione tabelle


create table if not exists category (
id_category int (10) not null auto_increment,
category_name varchar(50) not null,
primary key(id_category)
);


create table if not exists product (
id_product int (5) not null auto_increment,
product_name varchar(50) not null,
id_category int(4) not null ,
price float(4,2) not null,
primary key (id_product),
foreign key (id_category) references category(id_category)
);


create table if not exists region(
id_region int(5) not null auto_increment,
nome_region varchar(50) not null,
primary key (id_region)
); 


create table if not exists sales (
id_transaction int(50) not null auto_increment,
date date  not null,
id_region int(5) not null,
id_product int(5) not null,
primary key (id_transaction),
foreign key (id_region) references region (id_region), 
foreign key (id_product) references product(id_product)
);



create table if not exists state(
id_state int (10) not null auto_increment,
state_name varchar(50) not null,
id_region int(5) not null,
primary key (id_state),
foreign key (id_region) references region(id_region)
);




-- popolare tabelle

insert into category (category_name) 
values
('Action Figures'),
('Board Games'),
('Dolls & Plushies'),
('Educational Toys'),
('Vehicles & Playsets'),
('Construction Sets'),
('Arts & Crafts'),
('Outdoor Toys'),
('Sports & Fitness'),
('Baby & Toddler Toys');


insert into product (product_name, id_category, price) 
values
('Supereroe', 1, 29.99),
('Strategia', 2, 39.99),
('Principessa', 3, 19.99),
('Conto', 4, 14.99),
('Macchina telecomandata', 5, 49.99),
('Castello', 6, 69.99),
('Pittura', 7, 12.99),
('Acquatico', 8, 24.99),
('Pallone da calcio', 9, 9.99),
('Sonaglio per neonati', 10, 7.99);


insert into region (nome_region)
 values
('Nord Europa'),
('Centro Europa'),
('Sud Europa'),
('Est europa'),
('Usa');


insert into sales (date, id_region, id_product) 
values
('2024-02-23', 1, 1),
('2024-02-22', 2, 1),
('2024-02-21', 3, 3),
('2024-02-20', 1, 4),
('2024-02-19', 4, 5),
('2024-02-18', 2, 6),
('2024-02-17', 3, 7),
('2024-02-16', 4, 8),
('2024-02-15', 5, 1),
('2024-02-14', 4, 2),
('2023-02-23', 1, 1),
  ('2023-02-22', 2, 2),
  ('2023-02-21', 3, 3),
  ('2023-02-20', 1, 4),
  ('2023-02-19', 4, 5),
  ('2023-02-18', 2, 6),
  ('2023-02-17', 3, 7),
  ('2023-02-16', 4, 8),
  ('2023-02-15', 5, 1),
  ('2023-02-14', 4, 2),
   ('2022-02-03', 2, 5),
  ('2022-02-02', 1, 6),
  ('2022-02-01', 3, 7),
  ('2022-01-31', 4, 8),
  ('2022-01-30', 5, 1),
  ('2022-01-29', 2, 2),
  ('2022-01-28', 3, 3),
  ('2022-01-27', 4, 4),
  ('2022-01-26', 5, 5),
  ('2022-01-25', 4, 6),
  ('2021-02-13', 3, 3),
  ('2021-02-12', 2, 4),
  ('2021-02-11', 1, 5),
  ('2021-02-10', 4, 6),
  ('2021-02-09', 5, 7),
  ('2021-02-08', 2, 8),
  ('2021-02-07', 3, 1),
  ('2021-02-06', 4, 2),
  ('2021-02-05', 5, 3),
  ('2021-02-04', 4, 4),
  ('2020-02-23', 1, 1),
  ('2020-02-22', 2, 2),
  ('2020-02-21', 3, 3),
  ('2020-02-20', 1, 4),
  ('2020-02-19', 4, 5),
  ('2020-02-18', 2, 6),
  ('2020-02-17', 3, 7),
  ('2020-02-16', 4, 8),
  ('2020-02-15', 5, 1),
  ('2020-02-14', 4, 2);


insert into state (state_name, id_region)
 values
('Inghilterra', 1),
('Norvegia', 1),
('Fillandia', 1),
('Germania', 2),
('Francia', 2),
('Italia', 3),
('Grecia', 3),
('Romania', 4),
('Bulgaria', 4),
('New York', 5);

-- QUESITI:

-- 1. Verificare che i campi definiti come PK siano univoci. 

SELECT id_category, COUNT(*)
FROM category
GROUP BY id_category
HAVING COUNT(*) > 1;

SELECT id_product, COUNT(*)
FROM product
GROUP BY id_product
HAVING COUNT(*) > 1;

SELECT id_region, COUNT(*)
FROM region
GROUP BY id_region
HAVING COUNT(*) > 1;

SELECT id_transaction, COUNT(*)
FROM sales
GROUP BY id_transaction
HAVING COUNT(*) > 1;

SELECT id_state, COUNT(*)
FROM state
GROUP BY id_state
HAVING COUNT(*) > 1;


-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 



select product.product_name as Product, sum(product.price) as Total, year(sales.date) as Year
from product
right join sales
using(id_product)
group by product.product_name, year(sales.date);


-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 


select state.state_name as State, year(sales.date) as Year, sum(product.price) as Total
from product
left join sales
using(id_product)
join region
using(id_region)
join state
using (id_region)
group by state.state_name, year(sales.date)
order by Year, total desc;



-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 



select category.category_name as Category, count(sales.id_transaction) as Requests
from sales
join product
using (id_product)
join category
using(id_category)
group by category.category_name
order by count(sales.id_transaction) desc
limit 1;



-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 


select product.id_product as ID, product.product_name as Product
from product
where not exists(
select * 
from sales
where product.id_product=sales.id_product);

-- oppure

select product.id_product as ID, product.product_name as Product
from product
left join sales
using(id_product)
where sales.id_product is null;




-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).



select product.product_name as Product,  max(sales.date) as Last_date
from product
right join sales
using(id_product)
group by product.product_name;


/* BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto,
 la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
*/


select sales.id_transaction as Doc_Cod, sales.date as Date, product.product_name as Name_product, category.category_name as Category, state.state_name as State, region.nome_region as Region, 
case when   sales.date < date_sub(now(), interval 180 day) then "True" else "False" end as Bool
from sales
join product
using (id_product)
join category
using(id_category)
join region
using(id_region)
join state
using (id_region);

